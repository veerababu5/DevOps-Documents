# infra directory

This `infra` directory contains azd files used for `azd provision` and isn't used by the sample application.